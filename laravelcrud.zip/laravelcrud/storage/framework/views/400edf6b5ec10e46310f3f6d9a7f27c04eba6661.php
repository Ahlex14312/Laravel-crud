

<?php $__env->startSection('content'); ?>

<div class="mt-5">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div>
  <?php endif; ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
    <title>Laravel 8 CRUD Operations</title>
  </head>
  <body>
  <style>
    body {
        background: linear-gradient(to bottom, rgba(0, 0, 0, 0.45) 100%, transparent),
            url(https://images.pexels.com/photos/269077/pexels-photo-269077.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500);
        background-size: cover, cover;
        background-position: center, center;
        height: 100vh;
        width: 100%;
        overflow: hidden;
        font-family: 'Poppins', sans-serif;
    }
	tbody {
        height: 200px;
        width: 100%;
        overflow-y: scroll;
    }
    }
    </style>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="card" style="width: 70rem;">
                <div class="card-body bg-light">
                <h3 >Muñoz Memorial Hospital - Patients Record
				<span class="pull-right" style="margin-left:21rem"><a href="<?php echo e(route('patients.create')); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Add Patient</a><br>
			</h3>
</span>
  <table class="table table-bordered table-striped">
    <thead>
        <tr class="table-primary text-center">
          <td>Patient Id</td>
          <td>Patient Name</td>
          <td>Disease</td>
          <td>Bill</td>
          <td>Action</td>
        </tr>
    </thead>
    <tbody class="text-center">
        <?php $__currentLoopData = $patient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($patient->id); ?></td>
            <td><?php echo e($patient->patientname); ?></td>
            <td><?php echo e($patient->disease); ?></td>
            <td><?php echo e($patient->bill); ?></td>
            <td class="text-center">
                <a href="<?php echo e(route('patients.edit', $patient->id)); ?>" class="btn btn-success btn-sm">Update</a>
                <form action="<?php echo e(route('patients.destroy', $patient->id)); ?>" method="post" style="display: inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                  </form>
            </td> 
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>         </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
  </body>
  </html>
  
 
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelcrud\resources\views/index.blade.php ENDPATH**/ ?>