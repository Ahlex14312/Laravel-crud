@extends('layout')

@section('content')

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
  <title>Laravel 8 CRUD Operations</title>
</head>
<body>
<style>
    body {
        background: linear-gradient(to bottom, rgba(0, 0, 0, 0.45) 100%, transparent),
            url(https://images.pexels.com/photos/269077/pexels-photo-269077.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500);
        background-size: cover, cover;
        background-position: center, center;
        height: 100vh;
        width: 100%;
        overflow: hidden;
        font-family: 'Poppins', sans-serif;
    }

    input:focus,
    input.form-control:focus {
        border: 2px rgba(145, 135, 238, 1) solid;
        outline: none !important;
        outline-width: 0 !important;
        box-shadow: none;
        -moz-box-shadow: none;
        -webkit-box-shadow: none;
    }
    </style>
     <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="card" style="width: 40rem; height: 28rem;">
                <div class="card-body bg-light">
                <h3 style="text-align:center">Muñoz Memorial Hospital</h3>
  <div class="card-header" style="text-align:center">
    Add New Patient 
  </div>

  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div>
    @endif
      <form method="post" action="{{ route('patients.store') }}">
          <div class="form-group">
              @csrf
              <label for="patientname">Patient Name</label>
              <input type="text" class="form-control" name="patientname"/>
          </div>
          <div class="form-group">
              <label for="disease">Disease</label>
              <input type="text" class="form-control" name="disease"/>
          </div>
          <div class="form-group">
              <label for="bill">Bill</label>
              <input type="tel" class="form-control" name="bill"/>
          </div>
          <button type="submit" class="btn btn-block btn-primary">Add</button>
      </form>
  </div>

</div>
</div>
</div>
</div>
@endsection
</body>
</html>
